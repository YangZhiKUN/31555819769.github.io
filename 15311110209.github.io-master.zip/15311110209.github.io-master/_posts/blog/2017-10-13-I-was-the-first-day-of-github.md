---
layout: post
title: 我在github的第一天
categories: Blog
description: 代码可以创造无数的绮丽与神奇，而阅读能够升华我们的心灵和纯心。
keywords: github、first
---


# 1.搭建网站 #
  成功在github是搭建自己的个人网站，给自己点个赞先。
# 2. 学习和记录#
  在这儿开始记录自己的学习之路，一步一脚印。
<div align="center"><img width="192px" height="192px" src="https://15311110209.github.io//assets/images/qrcode.jpg"/></div>
